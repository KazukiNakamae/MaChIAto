# -*- coding: utf-8 -*-

from .MaChIAtoCORE import main
main()