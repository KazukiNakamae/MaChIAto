#!/usr/bin python
# -*- coding: utf-8 -*-


from MaChIAto import main

# This program can only work when you type "python .../MaChIAto.py". Do not import the file.
if __name__ == '__main__':
    main()