#!/usr/bin python
# -*- coding: utf-8 -*-


from MaChIAto import main


if __name__ == '__main__':
    main()